<?php
	include('connect.php');
	$userid = $_POST['userid'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$position=$_POST['position'];
	mysqli_query($link,"UPDATE user SET username='$username', password='$password', position='$position' WHERE user_id='$userid'");
	header("location: user.php");
?>